define(
({
	buttonOk: "OK",
	buttonCancel: "Annuler",
	buttonSave: "Enregistrer",
	itemClose: "Fermer"
})
);
