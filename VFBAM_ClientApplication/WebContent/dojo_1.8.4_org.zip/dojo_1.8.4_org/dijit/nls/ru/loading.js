define(
({
	loadingState: "Загрузка...",
	errorState: "Извините, возникла ошибка"
})
);
