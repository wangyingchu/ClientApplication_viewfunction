define(
({
		previousMessage: "Алдыңғы нұсқалар",
		nextMessage: "Басқа нұсқалар"
})
);
